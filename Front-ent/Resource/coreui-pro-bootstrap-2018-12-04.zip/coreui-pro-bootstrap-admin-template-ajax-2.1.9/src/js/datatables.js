/**
 * --------------------------------------------------------------------------
 * CoreUI Pro Boostrap Admin Template (2.0.1): datatables.js
 * Licensed under MIT (https://coreui.io/license)
 * --------------------------------------------------------------------------
 */
$('.datatable').DataTable();
$('.datatable').attr('style', 'border-collapse: collapse !important');
//# sourceMappingURL=datatables.js.map